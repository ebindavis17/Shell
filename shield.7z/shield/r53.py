import boto3
import re

client = boto3.client('route53')
shieldpro = boto3.client('shield','us-east-1')

HId = []
HId_strip = []
HZtagged = []
HZarn = []
pro = []


def hosted_zones():

   response = client.list_hosted_zones()
   for i in response['HostedZones']:
       HId.append(i['Id'])

   for i in HId:
       ID = i[i.rindex('/')+1:]

   HId_strip.append(ID)


   for j in HId_strip:

       response1 = client.list_tags_for_resources(
                   ResourceType = 'hostedzone',
                   ResourceIds = [ j ] )

       for i in response1['ResourceTagSets']:
           for j in i['Tags']:
               tags = {
               tag['Key']: tag['Value']
               for tag in i['Tags']
               }
           if 'Integrity' and 'Confidentiality' in tags:
               if (tags['Confidentiality'])== '1' and (tags['Integrity']) == '1':
                   HZtagged.append(i['ResourceId'])



def lambda_handler(event, context):


   account_id = boto3.client('sts').get_caller_identity().get('Account')

   hosted_zones()
   for i in HZtagged:
       HZarn.append('arn:aws:route53::{}:hostedzone/{}'.format( account_id, i ))


   protected = shieldpro.list_protections(MaxResults=100)

   for i in protected['Protections']:
       pro.append(i['ResourceArn'])

   final_list= (set(HZarn).difference(pro))
   for i in final_list:
       print(i)



if __name__ == '__main__':
     lambda_handler(
        {'invokingEvent': '{"messageType":"ScheduledNotification"}'}, None)
