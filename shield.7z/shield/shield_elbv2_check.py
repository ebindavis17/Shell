import boto3

elbv1ARN = []
elbv2 = []
pro = []

client = boto3.client('elbv2')
shieldpro = boto3.client('shield','us-east-1')

def elastic_load_bal():
   response = client.describe_load_balancers()
   for i in response['LoadBalancers']:
       if i['Type'] == 'application':

           elbv2.append(i['LoadBalancerArn'])

   for i in elbv2:
       response1 = client.describe_tags(
                 ResourceArns= [ i ] )

       for i in response1['TagDescriptions']:
           tags = {
               tag['Key']: tag['Value']
               for tag in i['Tags']
           }

       if 'Integrity' and 'Confidentiality' in tags:
           if (tags['Confidentiality'])== '1' and (tags['Integrity']) == '1':
               elbv1ARN.append(i['ResourceArn'])



def lambda_handler(event, context):

   elastic_load_bal()
   protected = shieldpro.list_protections(MaxResults=100)

   for i in protected['Protections']:
       pro.append(i['ResourceArn'])

   final_list= (set(elbv1ARN).difference(pro))
   for i in final_list:
       print(i)



if __name__ == '__main__':
     lambda_handler(
        {'invokingEvent': '{"messageType":"ScheduledNotification"}'}, None)

