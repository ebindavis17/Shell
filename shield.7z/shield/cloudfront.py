import boto3
from botocore.exceptions import ClientError

CFid = []
CFarn = []
pro = []
CFdistID = []
CFtagged = []

client = boto3.client('cloudfront')
shieldpro = boto3.client('shield','us-east-1')


def list_distribution():

   response = client.list_distributions()# MaxItems = '1')

   for i in response['DistributionList']['Items']:
       CFid.append(i['Id'])
       CFarn.append(i['ARN'])


   for j in CFarn:
       response1 = client.list_tags_for_resource(
                   Resource= j
                   )
       if not response1['Tags']['Items']:
           continue
       newDict = {d['Key']: d['Value'] for d in response1['Tags']['Items']}
       if newDict['Integrity'] == '1' and newDict['Confidentiality'] == '1':
           CFtagged.append(j)

def lambda_handler(event, context):

   account_id = boto3.client('sts').get_caller_identity().get('Account')

   list_distribution()

   try:
       protected = shieldpro.list_protections(MaxResults=100)

       for i in protected['Protections']:
           pro.append(i['ResourceArn'])

       final_list= (set(CFtagged).difference(pro))
       print("Resources to be added : ")
       for i in final_list:
           print(i)

   except ClientError as e:
       if e.response['Error']['Code'] == 'ResourceNotFoundException':
           print("No Shield Proctections are added yet in Account: {}".format(account_id))



if __name__ == '__main__':
     lambda_handler(
        {'invokingEvent': '{"messageType":"ScheduledNotification"}'}, None)
