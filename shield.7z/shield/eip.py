import boto3
from botocore.exceptions import ClientError

eip = []
eipAlloc = []
pro = []

client = boto3.client('ec2')
shieldpro = boto3.client('shield','us-east-1')

account_id = boto3.client('sts').get_caller_identity().get('Account')

def elastic_ip():

   response = client.describe_addresses(
               Filters=[

        {
            'Name':'tag:Confidentiality',
            'Values' : [ '1']    },
        {
            'Name':'tag:Integrity',
            'Values' : [ '1']    }

           ] )
   for i in response['Addresses']:
       eip.append(i['AllocationId'])

   if not eip:
       print('')
       print("No Elastic IPs are found in Account : {} with required tags". format( account_id ))
       print('')

def lambda_handler(event, context):

   elastic_ip()
   for i in eip:
       eipAlloc.append('arn:aws:ec2:eu-west-1:{}:eip-allocation/{}'.format( account_id , i ))

   try:

       protected = shieldpro.list_protections(MaxResults=100)

       for i in protected['Protections']:
           pro.append(i['ResourceArn'])

       final_list = (set(eipAlloc).difference(pro))
       for i in final_list:
           print(i)
   except ClientError as e:
       if e.response['Error']['Code'] == 'ResourceNotFoundException':

           print("No Shield Protection are added yet in Account:{}".format(account_id))
           print('')

if __name__ == '__main__':
     lambda_handler(
        {'invokingEvent': '{"messageType":"ScheduledNotification"}'}, None)