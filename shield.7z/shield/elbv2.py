import boto3
from botocore.exceptions import ClientError

elbv1 = []
elbv1ARN = []
elbv2 = []
pro = []

client = boto3.client('elbv2')
shieldpro = boto3.client('shield','us-east-1')

def elastic_load_bal():

   account_id = boto3.client('sts').get_caller_identity().get('Account')

   response = client.describe_load_balancers()

   for i in response['LoadBalancers']:
       if i['Type'] == 'application':

           elbv2.append(i['LoadBalancerArn'])

   if not elbv2:
       print("NO Application Load Balancer is found in account:{}".format( account_id ))

   for i in elbv2:
       response1 = client.describe_tags(
                 ResourceArns= [ i ] )

       for i in response1['TagDescriptions']:
           tags = {
               tag['Key']: tag['Value']
               for tag in i['Tags']
           }

       if 'Integrity' and 'Confidentiality' in tags:
           if (tags['Confidentiality'])== '1' and (tags['Integrity']) == '1':
               elbv1ARN.append(i['ResourceArn'])



def lambda_handler(event, context):

   elastic_load_bal()

   try:
       protected = shieldpro.list_protections(MaxResults=100)

       for i in protected['Protections']:
           pro.append(i['ResourceArn'])
       final_list= (set(elbv1ARN).difference(pro))
       for i in final_list:
           print(i)

   except ClientError as e:
       if e.response['Error']['Code'] == 'ResourceNotFoundException':
           print("No Shield Protection are added yet")

           #response = client.create_protection()


if __name__ == '__main__':
     lambda_handler(
        {'invokingEvent': '{"messageType":"ScheduledNotification"}'}, None)
