# Check if IAM role for AWS DDoS response team exists in the accounts where protections are enabled
#
# Trigger Type: Periodic 24 hrs.
# Scope of Changes: AWS Account

import boto3
import time
import json
from botocore.client import ClientError
from botocore.config import Config

# https://botocore.readthedocs.io/en/stable/reference/config.html
boto3_config = Config(retries={'max_attempts': 10})

global_region = 'us-east-1'
shield = boto3.client('shield', region_name=global_region, config=boto3_config)
iam = boto3.client('iam', region_name=global_region, config=boto3_config)

account_id = boto3.client('sts').get_caller_identity().get('Account')


def get_shield_protections():
    kwargs = {
        'MaxResults': 100,
    }
    next_token = None
    all_protections = []
    while True:
        try:
            response = shield.list_protections(**kwargs)
        except ClientError as error:
            if error.response['Error']['Code'] == 'ResourceNotFoundException':
                # No shield resources
                return []
            else:
                raise

        all_protections += [
            protection['ResourceArn']
            for protection in response['Protections']
        ]

        if 'NextToken' in response:
            kwargs['NextToken'] = response['NextToken']
        else:
            break

    return all_protections


def drt_iam_role_exists():
    drt_account = 'arn:aws:iam::232571688017:root'
    drt_policy_name = 'DRT-WAF-Support'

    paginator = iam.get_paginator('list_roles')
    response_iterator = paginator.paginate()

    drt_roles = [
        role['RoleName']
        for response in response_iterator
        for role in response['Roles']
        if drt_account in str(role['AssumeRolePolicyDocument'])
    ]

    for drt_role in drt_roles:
        inline_policies = iam.list_role_policies(RoleName=drt_role)
        for policy in inline_policies['PolicyNames']:
            if policy == drt_policy_name:
                return drt_role
            else:
                return False


def evaluate_compliance(account):
    protections = get_shield_protections()
    drt_iam_role = drt_iam_role_exists()

    if protections:
        if drt_iam_role:
            return 'COMPLIANT', 'IAM Role for AWS DRT is present'
        else:
            return 'NON_COMPLIANT', 'IAM Role for AWS DRT is not present'
    else:
        return 'NOT_APPLICABLE', \
               'IAM Role for AWS DRT is not applicable as there are no protected resources'


def get_evaluation(account):
    compliance_type, annotation = evaluate_compliance(account)

    return {
        'ComplianceResourceType': 'AWS::::Account',
        'ComplianceResourceId': account,
        'ComplianceType': compliance_type,
        'Annotation': annotation,
        'OrderingTimestamp': time.time()
    }


def get_evaluations(account):
    return [get_evaluation(account)]


def lambda_handler(event, context):
    evaluations = get_evaluations(account_id)

    if 'resultToken' in event and evaluations:
        result_token = event['resultToken']

        chunks = (evaluations[x:x + 100]
                  for x in xrange(0, len(evaluations), 100))

        config = boto3.client('config')
        for chunk in chunks:
            config.put_evaluations(
                Evaluations=chunk,
                ResultToken=result_token
            )
    else:
        print(json.dumps(evaluations, indent=2, sort_keys=True))
        print(len(evaluations))


if __name__ == '__main__':
    lambda_handler({'invokingEvent': '{"messageType":"ScheduledNotification"}'}, None)