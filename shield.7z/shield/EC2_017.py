#!/usr/bin/env python

# Check if EC2 instances send logs to CloudWatch Log group /var/log/messages every day.
# (enabled is COMPLIANT, disabled is NON_COMPLIANT)
#
# Trigger Type: Configuration AWS::EC2::Instance and Periodic 24 hrs
# Scope of Changes: AWS::EC2::Instance

import time
import json

import boto3
from botocore.client import ClientError
from botocore.config import Config

# https://botocore.readthedocs.io/en/stable/reference/config.html
config = Config(retries={'max_attempts': 10})

ec2 = boto3.client('ec2', config=config)
logs = boto3.client('logs', config=config)
monitored_states = ['running', 'stopping', 'stopped']


def evaluate_compliance(instance_id):
    """
    Check for recent log messages to check if CWA is still running
    """
    try:
        response = logs.get_log_events(
            logGroupName='/var/log/messages',
            logStreamName=instance_id,
            limit=1,
            startFromHead=False
        )

        if len(response['events']) == 0:
            return 'NON_COMPLIANT'

        current_timestamp = int(time.time())
        last_message_timestamp = int(response['events'][0]['timestamp']) / 1000

        # logs should be written per day to /var/log/messages for all
        # instances, number of seconds in a day = 86400, so taking 100,000
        # just to have buffer for logs.
        if (current_timestamp - last_message_timestamp) < 100000:
            return 'COMPLIANT'
        else:
            return 'NON_COMPLIANT'

    except ClientError as error:
        if error.response['Error']['Code'] == 'ResourceNotFoundException':
            return 'NON_COMPLIANT'
        else:
            raise



def get_evaluation(instance_id):
    return {
        'ComplianceResourceType': 'AWS::EC2::Instance',
        'ComplianceResourceId': instance_id,
        'ComplianceType': evaluate_compliance(instance_id),
        'Annotation': 'EC2 instance is not sending logs to CloudWatch Log group /var/log/messages.',
        'OrderingTimestamp': time.time()
    }


def lambda_handler(event, _context):
    """
    Handler for Lambda
    """
    invoking_event = json.loads(event['invokingEvent'])

    evaluations = []

    if invoking_event['messageType'] == 'ConfigurationItemChangeNotification':
        configuration_item = invoking_event['configurationItem']

        if configuration_item['configurationItemStatus'] != 'ResourceDeleted':
            instance_id = configuration_item['resourceId']
            state = configuration_item['configuration']['state']['name']

            if state in monitored_states:
                evaluations.append(get_evaluation(instance_id))

    elif invoking_event['messageType'] == 'ScheduledNotification':
        paginator = ec2.get_paginator('describe_instances')
        response_iterator = paginator.paginate(
            Filters=[{
                'Name': 'instance-state-name',
                'Values': monitored_states
            }],
        )

        for response in response_iterator:
            for reservation in response['Reservations']:
                for instance in reservation['Instances']:
                    instance_id = instance['InstanceId']
                    evaluations.append(get_evaluation(instance_id))

    else:
        raise ValueError('Unexpected messageType: %s' % invoking_event['messageType'])

    if 'resultToken' in event:
        result_token = event['resultToken']

        chunks = (evaluations[x:x + 100] for x in xrange(0, len(evaluations), 100))

        config = boto3.client('config')
        for chunk in chunks:
            config.put_evaluations(
                Evaluations=chunk,
                ResultToken=result_token
            )
    else:
        print(json.dumps(evaluations, indent=2, sort_keys=True))


if __name__ == '__main__':
    lambda_handler({'invokingEvent': '{"messageType":"ScheduledNotification"}'}, None)
