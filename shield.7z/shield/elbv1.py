import boto3
from botocore.exceptions import ClientError

elb = []
elbv1 = []
elbv1ARN = []
pro = []

client = boto3.client('elb')
shieldpro = boto3.client('shield','us-east-1')

def elastic_load_bal():

   account_id = boto3.client('sts').get_caller_identity().get('Account')

   response = client.describe_load_balancers()
   for i in response['LoadBalancerDescriptions']:
       elb.append(i['LoadBalancerName'])
#   print(elb)
   if not elb:
       print("No Classic Load Balancer is found in account:{}".format( account_id ))

   for i in elb:
       response1 = client.describe_tags(
                 LoadBalancerNames=[ i ]
                )
       for i in response1['TagDescriptions']:
           tags = {
               tag['Key']: tag['Value']
               for tag in i['Tags']
           }

       if 'Integrity' and 'Confidentiality' in tags:
           if (tags['Confidentiality'])== '1' and (tags['Integrity']) == '1':
               elbv1.append(i['LoadBalancerName'])

def lambda_handler(event, context):

   account_id = boto3.client('sts').get_caller_identity().get('Account')

   elastic_load_bal()
   for i in elbv1:
       elbv1ARN.append('arn:aws:elasticloadbalancing:eu-west-1:{}:loadbalancer/{}'.format( account_id , i ))

   try:
       protected = shieldpro.list_protections(MaxResults=100)

       for i in protected['Protections']:
           pro.append(i['ResourceArn'])

       final_list= (set(elbv1ARN).difference(pro))
       for i in final_list:
           print("Resources that are not yet added to the Shield Protected : ",i)

   except ClientError as e:
       if e.response['Error']['Code'] == 'ResourceNotFoundException':
           print("No Shield Protection are added yet")

if __name__ == '__main__':
     lambda_handler(
        {'invokingEvent': '{"messageType":"ScheduledNotification"}'}, None)
